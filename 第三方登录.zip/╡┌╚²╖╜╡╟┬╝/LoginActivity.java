package com.xyy.vwill;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.sina.weibo.sdk.auth.Oauth2AccessToken;
import com.sina.weibo.sdk.auth.WbConnectErrorMessage;
import com.sina.weibo.sdk.auth.sso.SsoHandler;
import com.tencent.connect.UserInfo;
import com.tencent.connect.auth.QQToken;
import com.tencent.mm.opensdk.modelmsg.SendAuth;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;
import com.tencent.tauth.IUiListener;
import com.tencent.tauth.Tencent;
import com.tencent.tauth.UiError;
import com.xykj.smssdk.SMSCallback;
import com.xykj.smssdk.SMSSdk;
import com.xyy.model.User;
import com.xyy.model.UserDetailInfo;
import com.xyy.net.DownloadRequestItem;
import com.xyy.net.FileRequestItem;
import com.xyy.net.NetManager;
import com.xyy.net.RequestItem;
import com.xyy.net.ResponceItem;
import com.xyy.net.StringRequestItem;
import com.xyy.net.imp.Callback;
import com.xyy.utils.Common;
import com.xyy.utils.Config;
import com.xyy.utils.Md5Util;
import com.xyy.utils.SharedPreferencesUtil;
import com.xyy.utils.TipsUtil;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;


/**
 * Created by admin on 2016/10/11.
 */
public class LoginActivity extends BaseActivity implements View.OnClickListener {
    //    private static final int MSG_PHONE_LOGIN = 1;
    private static final int MSG_TIME_TICK = 2;
    private static final int MSG_TIME_UP = 3;
    private EditText etName, etPsw;
    private View mainView;

    @Override
    protected int getType() {
        return TYPE_JUST_BACK_KEY;
    }

    @Override
    protected int getLayout() {
        return R.layout.activity_login;
    }

    @Override
    protected void initLayout() {
        mainView = findViewById(R.id.login_main_view);
        findViewById(R.id.btn_login).setOnClickListener(this);
        findViewById(R.id.tv_regist).setOnClickListener(this);
        etName = (EditText) findViewById(R.id.et_user_name);
        etPsw = (EditText) findViewById(R.id.et_psw);
        findViewById(R.id.tv_phone_login).setOnClickListener(this);
        findViewById(R.id.tv_qq_login).setOnClickListener(this);
        findViewById(R.id.tv_weixin_login).setOnClickListener(this);
        findViewById(R.id.tv_weibo_login).setOnClickListener(this);
    }

    @Override
    protected String getActivityTitle() {
        return getResources().getString(R.string.login);
    }

    private ProgressDialog dialog;

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_login:
                String name = etName.getText().toString();
                String psw = etPsw.getText().toString();
                if (!TextUtils.isEmpty(name) && !TextUtils.isEmpty(psw)) {
                    if (null == dialog) {
                        dialog = ProgressDialog.show(this, null, "正在登录中...");
                    } else {
                        dialog.show();
                    }
                    loginByUserName(name, Md5Util.getMD5String(psw));
                }
                break;
            case R.id.tv_regist:
                Intent it = new Intent(LoginActivity.this, RegistActivity.class);
                startActivity(it);
                break;
            case R.id.tv_phone_login:
                showPhoneLoginWindow();
                break;
            case R.id.btn_get_code:
                phone = etPhone.getText().toString();
                if (!TextUtils.isEmpty(phone)) {
                    SMSSdk.getInstance().getVerificationCode(phone);
                    btnGetCode.setEnabled(false);
                    btnGetCode.setTextColor(0xff666666);
                    //倒计时60s之后才能可用
                    startTime();
                }
                break;
            case R.id.btn_commit:
                String code = etCode.getText().toString();
                SMSSdk.getInstance().submitVerificationCode(phone, code);
                break;
            case R.id.tv_qq_login:
                loginByQQ();
                break;
            case R.id.tv_weixin_login:

                break;
            case R.id.tv_weibo_login:
                loginBySinaWeibo();
                break;

        }
    }

    //---------------------QQ登录--开始-------------------------//
    private Tencent mTencent;

    //使用QQ登录
    private void loginByQQ() {
        if (null == mTencent) {
            mTencent = Tencent.createInstance(Config.QQ_LOGIN_APP_ID, getApplicationContext());
        }
        mTencent.login(LoginActivity.this, "get_user_info", qqCallback);
    }

    private IUiListener qqCallback = new IUiListener() {

        @Override
        public void onComplete(Object response) {
            Toast.makeText(getApplicationContext(), "登录成功", Toast.LENGTH_SHORT).show();
            try {
                String openidString = ((JSONObject) response).getString("openid");
                //使用openId登录VWill服务器，如果返回来的用户数据中已经有昵称和头像信息，则表示之前已经登录过了，就不需要再从腾讯服务器上加载用户信息
                String token = ((JSONObject) response).getString("access_token");
                String expires_in = ((JSONObject) response).getString("expires_in");
                //处理第三方登录
                loginByQQOpenId(openidString, token, expires_in);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onError(UiError uiError) {

        }

        @Override
        public void onCancel() {

        }
    };

    //从腾讯服务端获取用户基本信息
    private void getQQUserInfo(String openidString, String token, String expires_in) {
        QQToken qqToken = mTencent.getQQToken();
        mTencent.setOpenId(openidString);
//                saveUser("44", "text", "text", 1);
        mTencent.setAccessToken(token, expires_in);
        UserInfo info = new UserInfo(getApplicationContext(), qqToken);

        info.getUserInfo(new IUiListener() {
            @Override
            public void onComplete(Object o) {
                JSONObject obj = (JSONObject) o;
                TipsUtil.log("-------获取QQ基本信息--------结果：" + obj.toString());
                String nick = obj.optString("nickname");
                String sex = obj.optString("gender");
                String photoUrl = obj.optString("figureurl_qq_2");
                //下载头像到本地，下载完毕时将用户基本信息提交到VWill服务器
                downloadPhoto(nick, sex, photoUrl);
            }

            @Override
            public void onError(UiError uiError) {

            }

            @Override
            public void onCancel() {

            }
        });
    }

    //下载头像到本地并更新用户信息
    private void downloadPhoto(final String nick, final String sex, String url) {
        final String savePath = getTempFolder() + System.currentTimeMillis();
        NetManager.getInstance().execute(new DownloadRequestItem.Builder()
                .url(url)
                .savePath(savePath)
                .build()
                , new Callback<Boolean>() {
            @Override
            public Boolean changeData(ResponceItem responceItem) {
                TipsUtil.log("==下载头像==");
                return responceItem.getCode() == 200;
            }

            @Override
            public void onResult(Boolean result) {
                //头像下载完毕，将用户信息提交到服务端
                if (result != null && result) {
                    File f = new File(savePath);
                    TipsUtil.log("==下载头像完毕==");
                    updateUserBaseInfo(nick, sex, f);
                }
            }
        });
    }

    //更改用户信息
    private void updateUserBaseInfo(String nick, String sex, File photoFile) {
        NetManager.getInstance().execute(new FileRequestItem.Builder()
                .url(Common.URL_UPDATE_BASE_INFO)
                .addHead("token", Common.TOKEN)
                .addStringParam("nick", nick)
                .addStringParam("sex", sex)
                .addFileParam(photoFile.getName(), photoFile)
                .build(), new Callback<User>() {
            @Override
            public User changeData(ResponceItem responceItem) {
                String json = responceItem.getString();
                if (!json.startsWith("{result:")) {
                    User u = JSON.parseObject(json, User.class);
                    ((VWillApp) getApplication()).setLoginUser(u);
                    return u;
                }
                return null;
            }

            @Override
            public void onResult(User o) {
                if (null != o) {
                    TipsUtil.showToast(LoginActivity.this, "登录成功");
                    finishThisActivity();
                }
            }
        });
    }

    //使用第三方的openId登录
    private void loginByQQOpenId(final String openId, final String token, final String expiresIn) {
        NetManager.getInstance().execute(new StringRequestItem.Builder()
                .url(Common.URL_LOGIN_BY_OPENID)
                .addStringParam("openid", openId)
                .build(), new ThirdLoginCallback() {
            @Override
            protected void loadInfoFromThirdPlatform() {
                //从腾讯服务器上获取用户QQ信息，更新用户信息
                getQQUserInfo(openId, token, expiresIn);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //很重要，不加的话没有返回
        if (null != mTencent) {
            mTencent.onActivityResultData(requestCode, resultCode, data, qqCallback);
            mTencent.handleResultData(data, qqCallback);
        }
        //sina login
        if (mSsoHandler != null) {
            mSsoHandler.authorizeCallBack(requestCode, resultCode, data);
        }
    }

    //第三方账号登录回调
    abstract class ThirdLoginCallback implements Callback<Object> {

        @Override
        public Object changeData(ResponceItem responceItem) {
            String json = responceItem.getString();
            if (!json.startsWith("{result:")) {
                //登录成功
                User user = JSON.parseObject(json, User.class);
                getUserDetail(user.getId());
                Common.TOKEN = responceItem.getHeads().get("token").get(0);
                //检测用户名是否是默认的
                if (user.getNick().equals("用户" + user.getId()) || "".equals(user.getPhoto())) {
                    //从第三方平台加载用户信息
                    loadInfoFromThirdPlatform();
                    return null;
                } else {
                    //记录登录成功的用户信息
                    ((VWillApp) getApplication()).setLoginUser(user);
                    return user;
                }
            } else {
                //登录失败
                try {
                    JSONObject obj = new JSONObject(json);
                    if (obj.optInt("result") == -1) {
                        return "用户名或者密码输入错误";
                    } else {
                        return obj.optString("extras");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        public void onResult(Object o) {
            optionResult(o);
        }

        protected abstract void loadInfoFromThirdPlatform();
    }

    //---------------------QQ登录--结束-------------------------//
    private String getTempFolder() {
        File f = new File(getExternalCacheDir().toString() + "/temp/");
        boolean r = f.exists();
        if (!r) {
            r = f.mkdirs();
        }
        if (r) {
            return f.getAbsolutePath();
        }
        return "/mnt/sdcard";

    }

    private void loginByUserName(String name, String psw) {
        NetManager.getInstance().execute(new StringRequestItem.Builder()
                .url(Common.URL_LOGIN)
                .addStringParam("name", name)
                .addStringParam("psw", psw)
                .build(), loginCallback);
    }

    private void loginByPhone(String phone) {
        NetManager.getInstance().execute(new StringRequestItem.Builder()
                .url(Common.URL_LOGIN_BY_PHONE)
                .addStringParam("phone", phone)
                .build(), loginCallback);
    }

    private Callback<Object> loginCallback = new Callback<Object>() {
        @Override
        public Object changeData(ResponceItem responce) {
            String json = responce.getString();
            try {
                JSONObject obj = new JSONObject(json);
                int result = obj.optInt("result");
                if (result == 0) {
                    //登录成功
                    User u = JSON.parseObject(json, User.class);
                    Common.TOKEN = responce.getHeads().get("token").get(0);
                    getUserDetail(u.getId());
                    return u;
                } else if (result == 2) {
                    String extras = obj.optString("extras");
                    return extras;
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        public void onResult(Object result) {
            dialog.dismiss();
            optionResult(result);
        }
    };

    private void getUserDetail(int userId) {
        NetManager.getInstance().execute(new RequestItem.Builder().url(Common.URL_GET_USER_DETAIL + "?u_id=" + userId).build(),
                new Callback<UserDetailInfo>() {
                    @Override
                    public UserDetailInfo changeData(ResponceItem responce) {
                        String json = responce.getString();
                        if (!json.startsWith("{result")) {
                            UserDetailInfo info = JSON.parseObject(json, UserDetailInfo.class);
                            ((VWillApp) getApplication()).setLoginUserDetail(info);
                            return info;
                        }else{
                            ((VWillApp) getApplication()).setLoginUserDetail(new UserDetailInfo());
                        }
                        return null;
                    }

                    @Override
                    public void onResult(UserDetailInfo result) {
                    }
                });
    }

    //--------------------手机验证登录--------------------//
    //倒计时线程
    private Thread mTimeThread;

    private void startTime() {
        if (null != mTimeThread && mTimeThread.isAlive()) {
            mTimeThread.interrupt();
        }
        mTimeThread = new Thread() {
            @Override
            public void run() {
                int max = 60;
                try {
                    while (max > 0) {
                        Thread.sleep(1000);
                        max--;
                        mHandler.obtainMessage(MSG_TIME_TICK, max).sendToTarget();
                    }
                } catch (InterruptedException e) {
                }
                mHandler.sendEmptyMessage(MSG_TIME_UP);
            }
        };
        mTimeThread.start();
    }

    private SMSCallback smsCallback = new SMSCallback() {
        @Override
        public void afterEvent(int i, final Object o) {
            switch (i) {
                case SMSSdk.EVENT_GET_OK:
                    //获取验证码成功
                    TipsUtil.log("获取成功");
                    break;
                case SMSSdk.EVENT_GET_FAIL:
                    TipsUtil.log("验证码获取失败");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            TipsUtil.showToast(LoginActivity.this,String.valueOf(o));
                        }
                    });
                    break;
                case SMSSdk.EVENT_VERIFY_OK:
                    //提交验证码成功
                    stopTimeTicker();
                    //登录
                    loginByPhone(phone);
                    break;
                case SMSSdk.EVENT_VERIFY_FAIL:
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            TipsUtil.showToast(LoginActivity.this,String.valueOf(o));
                        }
                    });
                    break;
            }
        }
    };

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case MSG_TIME_TICK:
                    int current = (Integer) msg.obj;
                    String str = "(" + current + "s)后重新获取";
                    btnGetCode.setText(str);
                    break;
                case MSG_TIME_UP:
                    btnGetCode.setText(R.string.tx_get_code);
                    btnGetCode.setTextColor(0xff333333);
                    btnGetCode.setEnabled(true);
                    break;
            }
        }
    };

    private String phone;
    private EditText etPhone, etCode;
    private TextView btnGetCode;
    private PopupWindow phoneLoginWindow;

    private void showPhoneLoginWindow() {
        if (null == phoneLoginWindow) {
            View layout = getLayoutInflater().inflate(R.layout.window_phone_login_layout, null);
            btnGetCode = layout.findViewById(R.id.btn_get_code);
            btnGetCode.setOnClickListener(this);
            layout.findViewById(R.id.btn_commit).setOnClickListener(this);
            etPhone = (EditText) layout.findViewById(R.id.et_phone);
            etCode = (EditText) layout.findViewById(R.id.et_code);
            phoneLoginWindow = new PopupWindow(layout, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            phoneLoginWindow.setBackgroundDrawable(new ColorDrawable());
            phoneLoginWindow.setFocusable(true);
            phoneLoginWindow.setOutsideTouchable(true);
            phoneLoginWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
                @Override
                public void onDismiss() {
                    stopTimeTicker();
                }
            });
        }
        phoneLoginWindow.showAtLocation(mainView, Gravity.CENTER, 0, 0);
    }

    private void stopTimeTicker(){
        //停止倒计时
        if (null != mTimeThread && mTimeThread.isAlive()) {
            mTimeThread.interrupt();
            mTimeThread = null;
        }
    }

    private void hideWindow() {
        if (null != phoneLoginWindow && phoneLoginWindow.isShowing()) {
            phoneLoginWindow.dismiss();
        }
    }
    //----------------手机验证--结束-------------------------------------//

    //----------------微信登录--开始--------------------------------//
    private IWXAPI api;

    private void loginByWeChat() {
        if (null == api) {
            //通过WXAPIFactory工厂获取IWXApI的示例
            api = WXAPIFactory.createWXAPI(this, Config.APP_ID_WX, true);
            //将应用的appid注册到微信
            api.registerApp(Config.APP_ID_WX);
        }
        SendAuth.Req req = new SendAuth.Req();
        req.scope = "snsapi_userinfo";
//     req.scope = "snsapi_login";//提示 scope参数错误，或者没有scope权限
        req.state = "wechat_sdk_微信登录";
        api.sendReq(req);
    }
    //----------------微信登录--结束--------------------------------//

    //登录结果的处理
    @SuppressLint("WrongConstant")
    private void optionResult(Object obj) {
        if (obj != null) {
            if (obj instanceof User) {
                hideWindow();
                User user = (User) obj;
                //记录登录成功的用户信息
                ((VWillApp) getApplication()).setLoginUser(user);
                //启动实时消息服务
                Intent it = new Intent(LoginActivity.this, VWillService.class);
                startService(it);
                finishThisActivity();
            } else {
                String extras = (String) obj;
                Toast.makeText(LoginActivity.this, extras, Toast.LENGTH_LONG).show();
            }
        }
    }

    /**
     * 退出当前Activity
     */
    private void finishThisActivity(){
        //如果本地记录是共享位置的，则登录成功时启动位置共享
        if(SharedPreferencesUtil.getInstance(this).isRecordLocation()) {
            Intent it = new Intent(LoginActivity.this, CacheOrLocationService.class);
            it.putExtra("is_record", true);
            startService(it);
        }
        setResult(RESULT_OK);
        finish();
    }
    //-----------微博登录--开始-------------------//
    /**
     * 新浪微博
     */
    private SsoHandler mSsoHandler;
    /**
     * 封装了 "access_token"，"expires_in"，"refresh_token"，并提供了他们的管理功能
     */
    private Oauth2AccessToken mAccessToken;

    private void loginBySinaWeibo() {
        if (null == mSsoHandler) {
            //新浪微博
            mSsoHandler = new SsoHandler(LoginActivity.this);
        }
        //授权方式有三种，第一种对客户端授权 第二种对Web短授权，第三种结合前两中方式
        mSsoHandler.authorize(new SelfWbAuthListener());
    }

    private class SelfWbAuthListener implements com.sina.weibo.sdk.auth.WbAuthListener {
        @Override
        public void onSuccess(Oauth2AccessToken token) {
            mAccessToken = token;
            TipsUtil.log("====>" + mAccessToken.toString());
            loginBySinaUid();
        }

        @Override
        public void cancel() {
            TipsUtil.log("取消授权---sina---");
        }

        @Override
        public void onFailure(WbConnectErrorMessage errorMessage) {
            TipsUtil.showToast(LoginActivity.this, errorMessage.getErrorMessage());
        }
    }

    private void loginBySinaUid() {
        NetManager.getInstance().execute(new StringRequestItem.Builder()
                .url(Common.URL_LOGIN_BY_OPENID)
                .addStringParam("openid", mAccessToken.getUid())
                .build(), new ThirdLoginCallback() {
            @Override
            protected void loadInfoFromThirdPlatform() {
                //新浪上获取用户信息
//                if (mAccessToken.isSessionValid()) {
                //获取个人资料
                //https://api.weibo.com/2/users/show.json
                NetManager.getInstance().execute(
                        new RequestItem("https://api.weibo.com/2/users/show.json?uid=" + mAccessToken.getUid() + "&access_token=" + mAccessToken.getToken()),
                        new Callback<JSONObject>() {
                            @Override
                            public JSONObject changeData(ResponceItem responce) {
                                String json = responce.getString();
                                try {
                                    JSONObject obj = new JSONObject(json);
                                    return obj;
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                return null;
                            }

                            @Override
                            public void onResult(JSONObject result) {
                                TipsUtil.log("用户信息获取完毕 ：" + result);
                                if (result != null) {
                                    String headUrl = result.optString("profile_image_url");
                                    String sex = "m".equals(result.optString("gender")) ? "男" : "女";
                                    String name = result.optString("name");
                                    downloadPhoto(name, sex, headUrl);
                                }
                            }
                        });

//                }
            }
        });
    }
    //-----------微博登录--结束-------------------//

    @Override
    protected void onCreate(Bundle savedInstanceState) {
//        SMSSDK.initSDK(getApplicationContext(), "18624acc9fd02", "1c00dc1d7ddf93ec5d34ff9febf8c4a2");
        SMSSdk.getInstance().registerEventHandler(smsCallback);
        super.onCreate(savedInstanceState);

    }

    @Override
    protected void onDestroy() {
        SMSSdk.getInstance().registerEventHandler(smsCallback);
        hideWindow();
        super.onDestroy();
        if (null != dialog) {
            dialog = null;
        }
    }

}
